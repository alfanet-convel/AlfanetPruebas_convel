﻿using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Web.Security;
////////////////////////////////////////
using System.IO;
using System.Net;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel.Description;
using WebServiceAlfaBDU;
using System.Data;
///////////////////////////////////////////////////

/// <summary>
/// Descripción breve de InterOpAlfaNet_Sage
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class InterOpAlfaNet_Sage : System.Web.Services.WebService {

    //string Procedencia_Codigo ="";
    FuncionalidadServicioImplementacion bdu = new FuncionalidadServicioImplementacion();

    public InterOpAlfaNet_Sage () {

        //Eliminar la marca de comentario de la línea siguiente si utiliza los componentes diseñados 
        //InitializeComponent(); 
    }

    [WebMethod]
    public String BDU( String Expediente)
    {
        try
        {
            string Resultex;
            Resultex = "a";
            IAB_003Request RequestIAB003 = new IAB_003Request();
            IAB_003Response ResponseIAB003 = new IAB_003Response();
            //IMB_001Request RequestIAB001 = new IMB_001Request();
            IMB_001Response ResponseIMB001 = new IMB_001Response();

            ResponseIMB001 = bdu.IMB_001();

            RequestIAB003.NitOperador = "860014923";
            RequestIAB003.ClaseServicio = "13";
            RequestIAB003.NumeroExpediente = "52684";
            RequestIAB003.Sucursal = "4";
            ResponseIAB003 = bdu.IAB_003(RequestIAB003);
            
            return Resultex;
        }
        catch (Exception ex)
        {
            string Resultex;
            Resultex = "Ocurrio un problema. ";
            //Exception inner = Error.InnerException;
            Resultex += ErrorHandled.FindError(ex);
            Resultex += " " + ex.Message;
            return Resultex;
        }
    }

    [WebMethod]
    public string Radicar_Tramite(string NUI, string Nombre, string Direccion, string Ciudad, string Telefono1, string Telefono2, string Email1, string Email2, string Fax, string Naturaleza, string Dependencia, string Expediente, string Detalle, String NombreArchivo, Byte[] Archivo)
    {

        string coderror = null;
       

        //string ExpedienteBDU = BDU(Expediente);
        try
        {
            if (Expediente == "")
            {
                Expediente = null;
            }
            if (Detalle == "")
            {
                Detalle = null;
            }
            string respuesta;

            string sizeURL;
            string[] search;
            int sizeNombre;
            //string NombreArchivo = null;

            String Fecha = Convert.ToString(DateTime.Now);
            RadicarTramiteUAndesTableAdapters.Expediente_RadicarTramiteESPTableAdapter Tabla = new RadicarTramiteUAndesTableAdapters.Expediente_RadicarTramiteESPTableAdapter();
            RadicarTramiteUAndes.Expediente_RadicarTramiteESPDataTable Dtabla = new RadicarTramiteUAndes.Expediente_RadicarTramiteESPDataTable();
           /* RadicarTramiteUAndesTableAdapters.Consulta_NuiTableAdapter consultanui = new RadicarTramiteUAndesTableAdapters.Consulta_NuiTableAdapter();
            DataTable existe = new DataTable();
            existe = consultanui.GetData(NUI);

            string a = "";

            foreach (DataRow item in existe.Rows)
            {
                a = item["Column1"].ToString();
            }*/
            string Result;
           /* if (a == "0")
            {
                NUI = "TICS_" + NUI;
                // string mensaje = "Nos Encontramos en mantenimiento por favor comunicarse con Mintic.";

                // Result = "<Root>" + "<RadicadoCodigo></RadicadoCodigo>" + "<WFMovimientoFecha></WFMovimientoFecha><ExpedienteCodigo></ExpedienteCodigo>" + "<CodigoError>" + "1" + "</CodigoError>" + "<MensajeError>" + mensaje + "</MensajeError>" + "</Root>";
                // return Result;
            }*/
            Dtabla = Tabla.GetData(NUI, Nombre, Direccion, Ciudad, Telefono1, Telefono2, Email1, Email2, Fax, Naturaleza, Dependencia, Expediente, Detalle, Archivo.ToString(), Convert.ToString(DateTime.Now.ToString()));
            coderror = Dtabla[0].ErrorNumber;
            if (coderror == null || coderror == "")
            {
                coderror = "0";
            }
            else
            {
                coderror = "1";
            }
            //string Result;

            String Descarga = AdjuntarImgRad(Dtabla[0].RadicadoCodigo, NombreArchivo, Archivo);
            if (Descarga == "Proceso Finalizado")
            {
                Result = "<Root>" + "<RadicadoCodigo>" + Dtabla[0].RadicadoCodigo + "</RadicadoCodigo>" + "<WFMovimientoFecha>" + Dtabla[0].WFMovimientoFecha + "</WFMovimientoFecha>" + "<ExpedienteCodigo>" + Dtabla[0].ExpedienteCodigo + "</ExpedienteCodigo>" + "<CodigoError>" + coderror + "</CodigoError>" + "<MensajeError>" + Dtabla[0].ErrorMessage + "</MensajeError>" + "</Root>";
            }
            else
            {
                Result = "<Root>" + "<RadicadoCodigo>" + Dtabla[0].RadicadoCodigo + "</RadicadoCodigo>" + "<WFMovimientoFecha>" + Dtabla[0].WFMovimientoFecha + "</WFMovimientoFecha>" + "<ExpedienteCodigo>" + Dtabla[0].ExpedienteCodigo + "</ExpedienteCodigo>" + "<CodigoError>" + "1" + "</CodigoError>" + "<MensajeError>" + Descarga + "</MensajeError>" + "</Root>";
            }
            
            return Result;
        }
        catch (Exception ex)
        {
            string Resultex;

            String Result;
            Resultex = "Ocurrio un problema al Radicar. ";
            //Exception inner = Error.InnerException;
            Resultex += ErrorHandled.FindError(ex);
            Resultex += " " + ex.Message;
            Result = "<Root>" + "<RadicadoCodigo></RadicadoCodigo>" + "<WFMovimientoFecha></WFMovimientoFecha><ExpedienteCodigo></ExpedienteCodigo>" + "<CodigoError>" + "1" + "</CodigoError>" + "<MensajeError>" + Resultex + "</MensajeError>" + "</Root>";
            return Result;
        }

    }
    [WebMethod]
    public string AdjuntarImgRad( String Radicado, String NombreArchivo,Byte[] oArchivo)
    {
        
        try
        {
            String[] Extension = NombreArchivo.Split('.');
            String TipoArchivo = Extension[Extension.Length - 1];
            TipoArchivo = TipoArchivo.ToLower();

            if (oArchivo.Length >= 10240000)
            {
                return "El tamaño del archivo no corresponde con el maximo permitido";
            }
            if (TipoArchivo == "docx" || TipoArchivo == "doc" || TipoArchivo == "xls" || TipoArchivo == "xlsx" || TipoArchivo == "pdf" || TipoArchivo == "tif" || TipoArchivo == "tiff" || TipoArchivo == "jpg" || TipoArchivo == "txt" || TipoArchivo == "cvs" || TipoArchivo == "rtf" || TipoArchivo == "zip" || TipoArchivo == "rar" || TipoArchivo == "xml")
            {

            String Grupo = "Radicados";
            String Ano = DateTime.Today.Year.ToString();
            String Mes = DateTime.Today.Month.ToString();

            String PathVirtual = HttpContext.Current.Server.MapPath("~/AlfaNetRepositorioImagenes/" + Grupo + "/" + Ano + "/" + Mes + "/");

            DSImagenTableAdapters.RadicadoImagenTableAdapter TARadicadoImagen = new DSImagenTableAdapters.RadicadoImagenTableAdapter();
            DSImagenTableAdapters.ImagenRutaTableAdapter TAImgRuta = new DSImagenTableAdapters.ImagenRutaTableAdapter();
            DSImagen.ImagenRutaDataTable DTImgRuta = new DSImagen.ImagenRutaDataTable();

            Object CodigoRuta = TAImgRuta.SelectRutaCodigoByAnioMesGrupo(DateTime.Today.Year, DateTime.Today.Month, "1");
            int codigoR = Convert.ToInt32(CodigoRuta);

            if (CodigoRuta == null)
            {
                TAImgRuta.Insert(1, "", DateTime.Today.Year, DateTime.Today.Month, 1, PathVirtual);
            }
            CodigoRuta = TAImgRuta.SelectRutaCodigoByAnioMesGrupo(DateTime.Today.Year, DateTime.Today.Month, "1");
            codigoR = Convert.ToInt32(CodigoRuta);
            if (!Directory.Exists(PathVirtual))
            {
                Directory.CreateDirectory(PathVirtual);

            }
            NombreArchivo = Radicado + "1" + Ano + Mes + DateTime.Today.Day.ToString() + NombreArchivo;
            TARadicadoImagen.InsertRadicadoImagen("1", Convert.ToInt32(Radicado), NombreArchivo, codigoR);



            System.IO.File.WriteAllBytes(@PathVirtual + NombreArchivo, oArchivo);

              return "Proceso Finalizado";
            }
            else
            {
                return "El formato no corresponde con los permitidos(Word, Excel, Pdf, Jpg, Tif, Zip, Rar, Csv, Rtf, Xml)";
            }        
                    
          

            
        }

        catch (Exception Ex)
        {
            return Ex.Message.ToString();
        }

    }

    //Autor: Juan
    //Fecha: 06/04/2011
    //WebResponse resp = request.GetResponse(); 
    //var buffer = new byte[4096]; 
    //Stream responseStream = resp.GetResponseStream(); 
    //{   int count;   
    //    do   
    //    {     
    //        count = responseStream.Read(buffer, 0, buffer.Length);     
    //        memoryStream.Write(buffer, 0, responseStream.Read(buffer, 0, buffer.Length));   
    //    } 
    //    while (count != 0); 
    //} 
    //        resp.Close(); 
    //        byte[] memoryBuffer = memoryStream.ToArray(); 
    //           System.IO.File.WriteAllBytes(@"E:\sample1.pdf", memoryBuffer); 
    //            int s = memoryBuffer.Length;  
    //            BinaryWriter binaryWriter = new BinaryWriter(File.Open(@"E:\sample2.pdf", FileMode.Create)); 
    //            binaryWriter.Write(memoryBuffer); 

    //Autor: Anderson Ardila Martinez
    //Fecha: 06/02/2011
    //Consulta Comunicaciones x Tramite
    [WebMethod]
    public String[] ConsultaComunicadosXTramite(string vDocumentoCodigo, string vExpedienteCodigo)
    {
        try
        {
            DataTable tablaComunicado = new DataTable();
            DataTable tablaImagen = new DataTable();
            rutinas ejecutar = new rutinas();
            tablaComunicado = ejecutar.rtn_traer_ComunicadosxTramite(vDocumentoCodigo, vExpedienteCodigo);
            String[] registros = new String[tablaComunicado.Rows.Count + 1];

            if (tablaComunicado.Rows.Count == 0)
            {
                registros[0] = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + " < Root > " + "<ERROR>No hay registros con esos datos</ERROR>" + "</Root>";
                return registros;
            }

            string salida = " <?xml version=\"1.0\" encoding=\"utf-8\"?>";
            salida += "<Root>";
            registros[0] = salida;
            int contador = 0;
            int contador2 = 0;

            foreach (DataRow dr in tablaComunicado.Rows)
            {
                contador = contador + 1;
                contador2 = 0;
                salida = "";

                salida += "<Documento Nro=\"" + dr["DocumentoNro"].ToString() + "\"" + ">";

                //Ruta del Archivo
                tablaImagen = ejecutar.rtn_traer_RutaImagenxTramite(vDocumentoCodigo, dr["TipoDocumento"].ToString());
                foreach (DataRow dr2 in tablaImagen.Rows)
                {
                    contador2 = contador2 + 1;
                    salida += "<Archivo\"" + contador2 + "\"" + ">";
                    salida += dr2["Ruta"].ToString();
                    salida += "</Archivo>";
                }
                

                //Expediente
                salida += "<Expediente>";
                salida += dr["Expediente"].ToString();
                salida += "</Expediente>";
                

                //Tipo de Documento
                salida += "<Tipo_Documento>";
                salida += dr["TipoDocumento"].ToString();
                salida += "</Tipo_Documento>";

                //Detalle del Documento
                salida += "<Detalle_Documento>";
                salida += dr["Detalle"].ToString();
                salida += "</Detalle_Documento>";

                salida += "</Documento>";
      
                registros[contador] = salida;
            }

            registros[contador] += "</Root>";
            return registros;

        }
        catch (Exception Ex)
        {
            String[] registros = new String[1];
            registros[0] = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + " < Root > " + "<ERROR>" + Ex.Message.ToString() + "</ERROR>" + "</Root>";
            return registros;
        }
    }
    //Fin Anderson Ardila


    //Autor: Anderson Ardila Martinez
    //Fecha: 09/02/2011
    //Consulta Comunicaciones x Fecha y Naturaleza
    [WebMethod]
    public String[] ConsultaComunicadosXFechaNaturaleza(string vFechaInicial, string vNaturalezaCodigo)
    {
        try
        {
            DataTable tablaComunicado = new DataTable();
            rutinas ejecutar = new rutinas();
            tablaComunicado = ejecutar.rtn_traer_ComunicadosXFechaNaturaleza(vFechaInicial, vNaturalezaCodigo);
            String[] registros = new String[tablaComunicado.Rows.Count + 1];

            if (tablaComunicado.Rows.Count == 0)
            {
                registros[0] = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + " < Root > " + "<ERROR>No hay registros con esos datos</ERROR>" + "</Root>";
                return registros;
            }

            string salida = " <?xml version=\"1.0\" encoding=\"utf-8\"?>";
            salida += "<Root>";
            registros[0] = salida;
            int contador = 0;

            foreach (DataRow dr in tablaComunicado.Rows)
            {
                contador = contador + 1;
                salida = "";

                //Documento
                salida += "<Documento Nro=\"" + dr["DocumentoNro"].ToString() + "\"" + ">";

                //Expediente
                salida += "<Expediente>";
                salida += dr["Expediente"].ToString();
                salida += "</Expediente>";


                //Tipo de Documento
                salida += "<Tipo_Documento>";
                salida += dr["TipoDocumento"].ToString();
                salida += "</Tipo_Documento>";

                salida += "</Documento>";

                registros[contador] = salida;
            }

            registros[contador] += "</Root>";
            return registros;

        }
        catch (Exception Ex)
        {
            String[] registros = new String[1];
            registros[0] = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + " < Root > " + "<ERROR>" + Ex.Message.ToString() + "</ERROR>" + "</Root>";
            return registros;
        }
    }
    //Fin Anderson Ardila
        

    //Autor: Juan Ricardo Gonzalez Sepulveda
    //Fecha: 09/02/2011
    //Consulta RegistroCoumenicaciones enviadas, 
    [WebMethod]
    public string Registrar_Tramite(string DependenciaRemite, String CodDestino, string NomDestino, string WFTipo, String [] RadFuente, string Expediente, string Naturaleza, String SerieDocumental, string Detalle, String NombreArchivo, Byte[] Archivo)
    {
        RegistroBLL RegBLL = new RegistroBLL();

        if (Expediente == "")
        {
            Expediente = null;
        }
        if (Detalle == "")
        {
            Detalle = null;
        }

        string coderror = null;
        string respuesta;
        string sizeURL;
        string[] search;
        int sizeNombre;
        string Result = null;
        String Descarga;

        //Codigo Temporal Simular Session Usuario        
        
                
        try
        {
            MembershipUser m = Membership.GetUser("TLINEA");

            String Fecha = Convert.ToString(DateTime.Now);

            Result = RegBLL.AddRegistro("2", DateTime.Now, CodDestino, null, DependenciaRemite, Naturaleza, Convert.ToInt32(RadFuente[0].ToString()), Detalle, null, null, null, null, m.ProviderUserKey.ToString(), Expediente, "TL", SerieDocumental, null, "0", "2", DateTime.Now, DateTime.Now, 0, Detalle, "0");
            //RadicarTramiteUAndesTableAdapters.Expediente_RadicarTramiteUATableAdapter Tabla = new RadicarTramiteUAndesTableAdapters.Expediente_RadicarTramiteUATableAdapter();
            //RadicarTramiteUAndes.Expediente_RadicarTramiteUADataTable Dtabla = new RadicarTramiteUAndes.Expediente_RadicarTramiteUADataTable();
            //Dtabla = Tabla.GetData(NUI, Nombre, Direccion, Ciudad, Telefono1, Telefono2, Email1, Email2, Fax, Naturaleza, Dependencia, Expediente, Detalle, Archivo.ToString(), DateTime.Now);
            //coderror = Dtabla[0].ErrorNumber;
            //if (coderror == null)
            //{
            //    coderror = "0";
            //}
            //else
            //{
            //    coderror = "1";
            //}
            
            Descarga = AdjuntarImgReg(Result, NombreArchivo, Archivo);
            if (Descarga == "Proceso Finalizado")
            {
                Result = "<Root>" + "<RegistroCodigo>" + Result + "</RegistroCodigo>" + "<WFMovimientoFecha>" + Fecha + "</WFMovimientoFecha>" + "<ExpedienteCodigo>" + Expediente + "</ExpedienteCodigo>" + "<CodigoError>" + coderror + "</CodigoError>" + "<MensajeError>" + "Dtabla[0].ErrorMessage" + "</MensajeError>" + "</Root>";
            }
            else
            {
                Result = "<Root>" + "<RegistroCodigo>" + Result + "</RegistroCodigo>" + "<WFMovimientoFecha>" + Fecha + "</WFMovimientoFecha>" + "<ExpedienteCodigo>" + Expediente + "</ExpedienteCodigo>" + "<CodigoError>" + "1" + "</CodigoError>" + "<MensajeError>" + Descarga + "</MensajeError>" + "</Root>";
            }

            return Result;
        }
        catch (Exception ex)
        {
            string Resultex;

            
            Resultex = "Ocurrio un problema al Radicar. ";
            //Exception inner = Error.InnerException;
            Resultex += ErrorHandled.FindError(ex);
            Resultex += " " + ex.Message;
            Result = "<Root>" + "<RegistroCodigo></RegistroCodigo>" + "<WFMovimientoFecha></WFMovimientoFecha><ExpedienteCodigo></ExpedienteCodigo>" + "<CodigoError>" + "1" + "</CodigoError>" + "<MensajeError>" + Resultex + "</MensajeError>" + "</Root>";
            return Result;
        }

    }
    [WebMethod]
    public string AdjuntarImgReg(String Registro, String NombreArchivo, Byte[] oArchivo)
    {

        try
        {
            String[] Extension = NombreArchivo.Split('.');
            String TipoArchivo = Extension[Extension.Length - 1];
            TipoArchivo = TipoArchivo.ToLower();

            if (oArchivo.Length >= 10240000)
            {
                return "El tamaño del archivo no corresponde con el maximo permitido";
            }
            if (TipoArchivo == "docx" || TipoArchivo == "doc" || TipoArchivo == "xls" || TipoArchivo == "xlsx" || TipoArchivo == "pdf" || TipoArchivo == "tif" || TipoArchivo == "tiff" || TipoArchivo == "jpg" || TipoArchivo == "txt" || TipoArchivo == "cvs" || TipoArchivo == "rtf" || TipoArchivo == "zip" || TipoArchivo == "rar")
            {
                String Grupo = "Registros";
                String Ano = DateTime.Today.Year.ToString();
                String Mes = DateTime.Today.Month.ToString();

                String PathVirtual = HttpContext.Current.Server.MapPath("~/AlfaNetRepositorioImagenes/" + Grupo + "/" + Ano + "/" + Mes + "/");

                DSImagenTableAdapters.RegistroImagenTableAdapter TARegistroImagen = new DSImagenTableAdapters.RegistroImagenTableAdapter();

                DSImagenTableAdapters.ImagenRutaTableAdapter TAImgRuta = new DSImagenTableAdapters.ImagenRutaTableAdapter();
                DSImagen.ImagenRutaDataTable DTImgRuta = new DSImagen.ImagenRutaDataTable();

                Object CodigoRuta = TAImgRuta.SelectRutaCodigoByAnioMesGrupo(DateTime.Today.Year, DateTime.Today.Month, "2");
                int codigoR = Convert.ToInt32(CodigoRuta);

                if (CodigoRuta == null)
                {
                    TAImgRuta.Insert(2, "", DateTime.Today.Year, DateTime.Today.Month, 2, PathVirtual);
                }
                CodigoRuta = TAImgRuta.SelectRutaCodigoByAnioMesGrupo(DateTime.Today.Year, DateTime.Today.Month, "2");
                codigoR = Convert.ToInt32(CodigoRuta);
                if (!Directory.Exists(PathVirtual))
                {
                    Directory.CreateDirectory(PathVirtual);
                }
                NombreArchivo = Registro + "2" + Ano + Mes + DateTime.Today.Day.ToString() + NombreArchivo;
                TARegistroImagen.InsertRegistroImagen("2", Convert.ToInt32(Registro), NombreArchivo, codigoR);
                
                System.IO.File.WriteAllBytes(@PathVirtual + NombreArchivo, oArchivo);

                return "Proceso Finalizado";
            }
            else
            {
                return "El formato no corresponde con los permitidos(Word, Excel, Pdf, Jpg, Tif, Zip, Rar, Csv, Rtf)";
            }




        }

        catch (Exception Ex)
        {
            return Ex.Message.ToString();
        }

    }
    //Fin Juan Ricardo Gonzalez Sepulveda
    }