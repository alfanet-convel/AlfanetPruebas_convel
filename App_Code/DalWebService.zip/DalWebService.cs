﻿using System;
using System.Data;
using System.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using System.Data.Common;

/// <summary>
/// Descripción breve de DalWebService
/// </summary>
public class DalWebService
{
    Database DB;
    public string asignarTramite(string documento, string serie)
    {
        string resultado = string.Empty;
        try
        {
            DB = DatabaseFactory.CreateDatabase("ConnStrSQLServer");
            using (DbCommand dbCommand = DB.GetStoredProcCommand("Asignar_Tramite_WebService"))
            {

                DB.AddInParameter(dbCommand, "DocumentoCodigo", DbType.Int32, Convert.ToInt32(documento));
                DB.AddInParameter(dbCommand, "SerieCodigo", DbType.String, serie);
                DB.AddOutParameter(dbCommand, "resultado", DbType.String, 500);                
                DB.ExecuteDataSet(dbCommand);
                resultado = DB.GetParameterValue(dbCommand, "@resultado").ToString();
                return resultado;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    internal int ValidarDocumento(string documento)
    {
        int result = 0;
        try
        {
            DB = DatabaseFactory.CreateDatabase("ConnStrSQLServer");
            using (DbCommand dbCommand = DB.GetStoredProcCommand("validarDocumento_WebService"))
            {

                DB.AddInParameter(dbCommand, "documento", DbType.String, Convert.ToInt32(documento));
                result = Convert.ToInt32(DB.ExecuteScalar(dbCommand));
                return result;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    internal int ValidarSerie(string serie)
    {
        int result = 0;
        try
        {
            DB = DatabaseFactory.CreateDatabase("ConnStrSQLServer");
            using (DbCommand dbCommand = DB.GetStoredProcCommand("validarSerie_WebService"))
            {

                DB.AddInParameter(dbCommand, "serie", DbType.String, serie);
                result = Convert.ToInt32(DB.ExecuteScalar(dbCommand));
                return result;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
